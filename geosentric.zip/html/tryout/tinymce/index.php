<!DOCTYPE html>
<html>
  <head>
    <script src="tinymce.min.js" referrerpolicy="origin"></script>
    <script src="custom.tinymce.js"></script>
  </head>
  <body>
    <textarea id="rich-editor" name="description">Next, use our Get Started docs to setup Tiny!</textarea>
  </body>
</html>